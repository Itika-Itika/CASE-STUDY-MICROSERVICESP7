package com.boot.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.boot.ms.entity.Students;
import com.boot.ms.model.FailureResponse;
import com.boot.ms.model.Room;
import com.boot.ms.model.StudentsRoomResponse;
import com.boot.ms.service.StudentsService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("/students")
public class StudentsController {
	@Autowired
	StudentsService service;
	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/getall")
	public ResponseEntity<List<Students>> getstudents() {
		return new ResponseEntity<List<Students>>(service.getStudents(), HttpStatus.OK);

	}

	@GetMapping("getstudents/{id}")
	public ResponseEntity<?> getstudents(@PathVariable int id) {
		Students students = service.getStudents(id);
		ResponseEntity<?> responseEntity = null;

		if (students == null) {
			responseEntity = new ResponseEntity<String>("No students present with given id  : " + id,
					HttpStatus.NOT_FOUND);

		} else {
			responseEntity = new ResponseEntity<Students>(students, HttpStatus.OK);
		}
		return responseEntity;
	}

	@DeleteMapping("/delete/{Student_Id}")
	public ResponseEntity<String> deleteStudentById(@PathVariable int Student_Id) {
		service.deleteStudentsById(Student_Id);
		return new ResponseEntity<String>("Deleted Succesfully", HttpStatus.OK);
	}

	@PostMapping("/insert")
	public ResponseEntity<Students> addCustomer(@RequestBody Students student) {
		return new ResponseEntity<Students>(service.addStudents(student), HttpStatus.OK);
	}

	@PutMapping("/update")

	public ResponseEntity<Students> updatedStudents(@RequestBody Students student) {
		Students studentList = service.getUpdatedStudents(student);
		return new ResponseEntity<Students>(studentList, HttpStatus.OK);
	}
	
	
	@SuppressWarnings("unchecked")
	@GetMapping("/getStudentsAndRoom/{sid}")
	@HystrixCommand(fallbackMethod = "myFallBackMethod")
	public ResponseEntity<?> getStudAndRoom(@PathVariable int Student_Id) {

		Students students = service.getStudents(Student_Id);
		ResponseEntity<?> responseEntity = null;

		if (students == null) {
			responseEntity = new ResponseEntity<String>("No students present with the given id: " + Student_Id,
					HttpStatus.NOT_FOUND);
		} else {
			List<Room> roomList = restTemplate
					.getForObject("http://localhost:5000/room/getRooms/" + students.getRoom_Number(), List.class);

			StudentsRoomResponse response = new StudentsRoomResponse();
			response.setStudents(students);
			response.setRoom(roomList);

			responseEntity = new ResponseEntity<StudentsRoomResponse>(response, HttpStatus.OK);
		}
		return responseEntity;
	}

	public ResponseEntity<?> myFallBackMethod(@PathVariable int Student_Id) {
		Students students = service.getStudents(Student_Id);
		ResponseEntity<?> responseEntity = null;

		FailureResponse response = new FailureResponse();
		response.setStudents(students);
		response.setMessage("Room service is down due to maintainance");
		responseEntity = new ResponseEntity<FailureResponse>(response, HttpStatus.SERVICE_UNAVAILABLE);
		return responseEntity;
	}
}