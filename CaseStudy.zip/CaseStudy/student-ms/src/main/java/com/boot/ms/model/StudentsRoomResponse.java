package com.boot.ms.model;

import java.util.List;

import com.boot.ms.entity.Students;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentsRoomResponse {

	private Students student;
	private List<Room> room;

	public void setStudents(Students students) {

	}

	public void setRoom(List<Room> roomList) {

	}
}
