package com.boot.ms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.ms.entity.Students;
import com.boot.ms.repository.StudentsRepo;

@Service
@Transactional
public class StudentsService {
	@Autowired
	StudentsRepo repository;

	public List<Students> getStudents() {
		return repository.findAll();

	}

	public Students getStudents(int Student_Id) {
		return repository.findById(Student_Id).orElse(null);
	}

	public void deleteStudentsById(int Student_Id) {
		repository.deleteById(Student_Id);
	}

	public Students addStudents(Students student) {
		return repository.save(student);
	}

	public Students getUpdatedStudents(Students student) {
		Students studentData = repository.findById(student.getStudent_Id()).get();
		studentData.setStudent_Id(student.getStudent_Id());
		studentData.setStudent_Name(student.getStudent_Name());
		studentData.setStudent_Number(student.getStudent_Number());
		studentData.setStudent_Age(student.getStudent_Age());
		studentData.setRoom_Number(student.getRoom_Number());
		return repository.save(studentData);
	}

}