package com.boot.ms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.boot.ms.entity.Students;

@Repository
public interface StudentsRepo extends JpaRepository<Students, Integer> {

}