package com.boot.ms.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "student")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Students {

	@Id
	@Column(name = "Student_Id")
	private int Student_Id;

	@Column(name = "Student_Name")
	private String Student_Name;

	@Column(name = "Student_Number")
	private int Student_Number;

	@Column(name = "Student_Age")
	private int Student_Age;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Room_Number", referencedColumnName = "Room_Number")
	private int Room_Number;
}