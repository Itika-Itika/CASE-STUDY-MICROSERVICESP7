package com.boot.ms.model;

public class Room {

}