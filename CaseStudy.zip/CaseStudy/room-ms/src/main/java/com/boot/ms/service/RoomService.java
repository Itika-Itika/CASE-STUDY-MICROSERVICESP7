package com.boot.ms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.ms.entity.Room;
import com.boot.ms.repository.RoomRepo;

@Service
public class RoomService {
	@Autowired
	RoomRepo repository;

	public List<Room> getRooms() {
		return repository.findAll();

	}

	public Room getRoom(int Room_Number) {
		return repository.findById(Room_Number).orElse(null);
	}

	public void deleteRoomById(int Room_Number) {
		repository.deleteById(Room_Number);

	}

	public void SaveOrUpdate(Room room) {
		repository.save(room);
	}

	public Room addRoom(Room room) {
		return repository.save(room);
	}

	public Room getUpdatedRoom(Room room) {
		Room roomData = repository.findById(room.getRoom_Number()).get();
		roomData.setRoom_Number(room.getRoom_Number());
		roomData.setRoom_Type(room.getRoom_Type());
		roomData.setOccupancy(room.getOccupancy());
		roomData.setCharges(room.getCharges());
		return repository.save(roomData);
	
	}
}