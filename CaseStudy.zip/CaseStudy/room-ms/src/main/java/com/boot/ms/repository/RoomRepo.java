package com.boot.ms.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.boot.ms.entity.Room;

@Repository
public interface RoomRepo extends JpaRepository<Room, Integer> {

	void deleteById(int Room_Number);

	@Transactional

	@Modifying

	@Query("delete from Room where Room_Number = Room_Number")
	public void deleteRoomById();

//	
//	  @Query(name = "deleteStudentsRoom", value =
//	  "delete from Students a where a.Room_Number =: Room_Number") public void
//	  deleteStudentsRoom();
//	 

}