package com.boot.ms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.boot.ms.entity.Room;
import com.boot.ms.service.RoomService;

@RestController
@RequestMapping("/room")
public class RoomController {
	@Autowired
	RoomService service;
	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/getall")
	public ResponseEntity<List<Room>> getRooms() {
		return new ResponseEntity<List<Room>>(service.getRooms(), HttpStatus.OK);
	}

	@GetMapping("/getroom/{number}")
	public ResponseEntity<?> getRoom(@PathVariable int number) {
		Room room = service.getRoom(number);
		ResponseEntity<?> responseEntity = null;

		if (room == null) {
			responseEntity = new ResponseEntity<String>("No Room present with given number  : " + number,
					HttpStatus.NOT_FOUND);

		} else {
			responseEntity = new ResponseEntity<Room>(room, HttpStatus.OK);
		}
		return responseEntity;

	}

//	@DeleteMapping("/deleteRoom/{number}")
//	public void deleteById(@PathVariable("number") int Room_Number) {
//		service.deleteRoomById(Room_Number);
//	}
//
//	@DeleteMapping("/deleteRoom")
//	public ResponseEntity<List<Room>> deleteRoomById(int Room_Number) {
//		service.deleteRoomById(Room_Number);
//		List<Room> room = new ArrayList<>();
//		service.getClass();
//		return new ResponseEntity<List<Room>>(room, HttpStatus.OK);
//	}

	@DeleteMapping("/delete/{Room_Number}")
	public ResponseEntity<String> deleteBankById(@PathVariable("Room_Number") int Room_Number) throws Exception {
		service.deleteRoomById(Room_Number);
		return new ResponseEntity<String>("Deleted", HttpStatus.OK);
	}

	@PostMapping("/insert")
	public ResponseEntity<Room> addRoom(@RequestBody Room room) {
		return new ResponseEntity<Room>(service.addRoom(room), HttpStatus.OK);
	}

	@PutMapping("/update")

	public ResponseEntity<Room> updatedCustomers(@RequestBody Room room) {
		Room roomList = service.getUpdatedRoom(room);
		return new ResponseEntity<Room>(roomList, HttpStatus.OK);
	}
}