package com.boot.ms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "room")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Room {
	@Id
	@Column(name = "Room_Number")
	private int Room_Number;

	@Column(name = "Room_Type")
	private String Room_Type;

	@Column(name = "Occupancy")
	private int Occupancy;

	@Column(name = "Charges")
	private int Charges;

}
